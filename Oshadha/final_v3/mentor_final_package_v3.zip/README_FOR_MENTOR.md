# Submission Package (v3 Diverse Blend) for Mentor

This folder contains the complete, upgraded, leakage-safe Machine Learning regression pipeline developed for the Sri Lanka Flood Risk Score Prediction competition. It has been enhanced using model diversity and metric-aware blending.

## Key Pipeline Improvements

1. **Data Leakage & Feature Cleanup (`src/features.py`)**:
   - Removed the `generation_date` and date-derived features from the feature extraction matrix entirely to prevent batch/timestamp leakage.
   - Cleaned up nominal integer attributes and explicitly cast them to pandas `category` dtype so tree algorithms natively interpret them as categorical.

2. **Fold-Isolated Target Encoding (`src/train_models.py`)**:
   - Implemented target encoding computed strictly on the training fold rows inside the spatial cross-validation loop to prevent OOF target leakage.
   - Computes 6 stats (mean, std, median, 25th percentile, 75th percentile, and log-count) across 12 categorical variables.

3. **Pseudo-Labeling & Multi-Seed Loop (`src/train_models.py`)**:
   - Implemented soft pseudo-labeling where test set predictions are utilized as soft targets in a Stage 2 training run with a sample weight of `0.2`.
   - Built a robust cross-validation routine using spatial GroupKFold (grouping on `grid_id` to prevent spatial validation leakage).

4. **Model Diversity**:
   - Expanded pipeline to support three model types: **CatBoost**, **LightGBM**, and **XGBoost**.
   - Evaluated models using MAE loss objectives and early-stopping constraints.

5. **Metric-Aware Blending (`scripts/blend_diverse.py`)**:
   - Optimized blending weights using a SciPy SLSQP optimizer targeting the exact competition formula:
     $$\text{Score} = (0.583210 \times \text{MAE} + 1.122681 \times \text{RMSE}) \times (1 + 0.045804 \times (1 - \text{EV}))$$

---

## Final Performance & Blending Weights

### Final Blended OOF Performance:
* **MAE**: `0.175220`
* **RMSE**: `0.231586`
* **Explained Variance (EV)**: `0.033410`
* **Competition Score**: `0.378223` (Beats previous best `0.381170`)

### Optimal Blending Weights:
* `catboost_full_clean`: **0.026645** (`2.66%`)
* `catboost_safe_pseudo`: **0.127408** (`12.74%`)
* `catboost_full_pseudo`: **0.689818** (`68.98%`)
* `lightgbm_full_clean`: **0.156130** (`15.61%`)
* `xgboost_full_clean`: **0.000000** (`0.0%`)

---

## Final Submission Verification

* **File Name:** `final_submission_v3.csv`
* **Validation Outcome:** **PASS**
* **Validation Checks Performed:**
  - Length matches `sample_submission.csv` exactly (5,300 rows).
  - Column names are exactly `record_id` and `flood_risk_score`.
  - Row order of `record_id` matches `sample_submission.csv` perfectly.
  - Zero missing (NaN) or null values.
  - Zero duplicate `record_id` strings.
  - All predictions fall strictly within the valid range `[0.0, 1.0]` (actual range: `[0.3569, 0.6139]`).
