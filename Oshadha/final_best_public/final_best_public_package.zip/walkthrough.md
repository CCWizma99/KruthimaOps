# Walkthrough: Final Public Best Submission Verification

We have inspected the repository's submission outputs for `v703`, `v704`, and `v705` and compared their prediction statistics, correlation, and mean absolute differences with `final_submission_v4.csv`.

## 1. Submission Comparison Statistics
Evaluating against `final_submission_v4.csv`:

* **submission_v703_optimized.csv (v703_opt)**:
  * Mean: `0.478331` | Std Dev: `0.051983` | Range: `[0.323090, 0.670425]`
  * Correlation with v4: `0.996853`
  * Mean Absolute Difference (MAD): `0.004663`
* **submission_v703.csv (v703_raw)**:
  * Mean: `0.478106` | Std Dev: `0.049926` | Range: `[0.315007, 0.648682]`
  * Correlation with v4: `0.996826`
  * MAD: `0.003993`
* **submission_v704_optimized.csv (v704_opt)**:
  * Mean: `0.478018` | Std Dev: `0.050470` | Range: `[0.323371, 0.648500]`
  * Correlation with v4: `0.994863`
  * MAD: `0.004774`
* **submission_v705_optimized.csv (v705_opt)**:
  * Mean: `0.477840` | Std Dev: `0.050728` | Range: `[0.318831, 0.648876]`
  * Correlation with v4: `0.996233`
  * MAD: `0.004398`

---

## 2. Selection & Copy Action
The file **`submission_v703_optimized.csv`** corresponds directly to the public leaderboard best score of `0.38203`.
* It was copied to **[final_best_public_submission.csv](file:///c:/Users/user/Downloads/KruthimaOps%20(1)/KruthimaOps/final_best_public_submission.csv)**.
* Standalone validation check completed with **PASS** (5,300 rows, matching record order, zero missing, zero duplicates, range `[0.323090, 0.670425]`).

---

## 3. Final Recommendation
* Keep and submit **[final_best_public_submission.csv](file:///c:/Users/user/Downloads/KruthimaOps%20(1)/KruthimaOps/final_best_public_submission.csv)** as the final submission file.

---

## 4. v706 Model Training & Evaluation
We trained the upgraded pipeline `v706` (featuring coordinate rounding, pre-imputation frequency count logs, decimal lengths, hydrology risk interactions, urban vulnerability scores, non-target aggregates, and fold-isolated target encodings) and ran evaluation on the same deduplicated basis.

### OOF Performance comparison (Deduplicated Basis):
* **v703 Optimized (Baseline)**:
  * MAE: `0.178066` | RMSE: `0.233989` | EV: `0.038936` | Local Score: `0.382681`
* **v706 Optimized**:
  * MAE: `0.179033` | RMSE: `0.234761` | EV: `0.032589` | Local Score: `0.384280`

### Submission Statistics:
* **v703 Optimized**: Mean `0.478331`, Std `0.051983`, Range `[0.323090, 0.670425]`
* **v706 Optimized**: Mean `0.477023`, Std `0.084200`, Range `[0.309345, 0.710700]`
* **Correlation**: `0.934789`
* **Mean Absolute Difference (MAD)**: `0.037213`

### Conservative Blending Results:
Evaluating weight blends of `w_v703 * v703_opt + w_v706 * v706_opt`:
* **98% v703 + 2% v706**: Local Score: `0.382689`
* **95% v703 + 5% v706**: Local Score: `0.382703`
* **90% v703 + 10% v706**: Local Score: `0.382731`
* **85% v703 + 15% v706**: Local Score: `0.382765`

The best conservative blend candidate is **98% v703 + 2% v706** (Score: `0.382689`), which has been saved to **[final_submission_v706_conservative.csv](file:///c:/Users/user/Downloads/KruthimaOps%20(1)/KruthimaOps/final_submission_v706_conservative.csv)** and verified successfully. Since it does not outperform the pure 100% v703 optimized baseline (`0.382681`), public leaderboard submission is not recommended for this blend.

