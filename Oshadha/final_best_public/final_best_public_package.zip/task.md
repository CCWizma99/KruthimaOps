# Execution Tasks: KruthimaOps Pipeline Upgrade

- [x] Modify features.py to remove generation_date and date-derived features, and ensure correct categorical treatment
- [x] Modify train_models.py to implement fold-isolated target encoding with 12 categorical variables and rich statistics
- [x] Implement multi-seed averaging and ensemble diversity (XGBoost, LightGBM, CatBoost) in train_models.py
- [x] Implement soft pseudo-labeling in train_models.py
- [x] Update train_models.py metrics reporting to show OOF MAE, RMSE, EV, and estimated LB score per model
- [x] Modify blend_best.py to use the true undisclosed competition metric for blending optimization
- [x] Run verification tests and evaluate results
- [x] Train v706 model using `train_v706_features.py`
- [x] Evaluate v706 local performance on deduplicated basis and compare with v703
- [x] Perform conservative blending experiments (98/2, 95/5, 90/10, 85/15) and save the best blend as `final_submission_v706_conservative.csv`
- [x] Perform validation checks on `final_submission_v706_conservative.csv`
