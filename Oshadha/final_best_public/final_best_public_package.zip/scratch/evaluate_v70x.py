import numpy as np
import pandas as pd
from sklearn.metrics import mean_absolute_error, mean_squared_error

def old_score_fn(mae, rmse, ev):
    return (0.583210 * mae + 1.122681 * rmse) * (1.0 + 0.045804 * (1.0 - ev))

def new_score_fn(mae, rmse, ev):
    return (0.563014 * mae + 1.168097 * rmse) * (1.0 + 0.141008 * (1.0 - ev)) - 0.041736

def main():
    train_df = pd.read_csv('data/train.csv')
    y_true = train_df.drop_duplicates()['flood_risk_score'].to_numpy(dtype=float)
    
    models = {
        'v703_raw': 'KruthimaOps/oof_v703.npy',
        'v703_optimized': 'KruthimaOps/oof_v703_optimized.npy',
        'v704_raw': 'KruthimaOps/oof_v704.npy',
        'v704_optimized': 'KruthimaOps/oof_v704_optimized.npy',
        'v705_raw': 'KruthimaOps/oof_v705.npy',
        'v705_optimized': 'KruthimaOps/oof_v705_optimized.npy',
    }
    
    for name, path in models.items():
        oof = np.load(path)
        mae = mean_absolute_error(y_true, oof)
        rmse = np.sqrt(mean_squared_error(y_true, oof))
        ev = 1.0 - np.var(y_true - oof) / np.var(y_true)
        
        old_score = old_score_fn(mae, rmse, ev)
        new_score = new_score_fn(mae, rmse, ev)
        
        print(f"{name:<15} | MAE: {mae:.6f} | RMSE: {rmse:.6f} | EV: {ev:.6f} | Old Score: {old_score:.6f} | New Score: {new_score:.6f}")

if __name__ == '__main__':
    main()
