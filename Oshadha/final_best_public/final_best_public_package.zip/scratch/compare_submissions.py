import os
import pandas as pd
import numpy as np

def main():
    root = "c:/Users/user/Downloads/KruthimaOps (1)/KruthimaOps"
    
    # Locate all submission files in the workspace containing v703/v704/v705
    sub_files = {}
    
    paths_to_check = [
        ("v703_opt", "KruthimaOps/submission_v703_optimized.csv"),
        ("v703_raw", "KruthimaOps/submission_v703.csv"),
        ("v704_opt", "KruthimaOps/submission_v704_optimized.csv"),
        ("v704_raw", "KruthimaOps/submission_v704.csv"),
        ("v705_opt", "KruthimaOps/submission_v705_optimized.csv"),
        ("v705_raw", "KruthimaOps/submission_v705.csv"),
        ("v703_opt_subs", "KruthimaOps/submissions/submission_v703_optimized.csv"),
        ("v703_raw_subs", "KruthimaOps/submissions/submission_v703.csv"),
        ("v704_opt_subs", "KruthimaOps/submissions/submission_v704_optimized.csv"),
        ("v704_raw_subs", "KruthimaOps/submissions/submission_v704.csv"),
        ("v705_opt_subs", "KruthimaOps/submissions/submission_v705_optimized.csv"),
        ("v705_raw_subs", "KruthimaOps/submissions/submission_v705.csv"),
    ]
    
    for label, rel_path in paths_to_check:
        abs_path = os.path.join(root, rel_path)
        if os.path.exists(abs_path):
            sub_files[label] = abs_path
            
    v4_path = os.path.join(root, "final_submission_v4.csv")
    if not os.path.exists(v4_path):
        print("Error: final_submission_v4.csv not found!")
        return
        
    df_v4 = pd.read_csv(v4_path)
    y_v4 = df_v4['flood_risk_score'].to_numpy()
    
    print(f"=== final_submission_v4.csv statistics ===")
    print(f"  Mean: {y_v4.mean():.6f}")
    print(f"  Std : {y_v4.std():.6f}")
    print(f"  Min : {y_v4.min():.6f}")
    print(f"  Max : {y_v4.max():.6f}")
    print("=" * 60)
    
    for label, path in sub_files.items():
        df = pd.read_csv(path)
        y = df['flood_risk_score'].to_numpy()
        
        mean = y.mean()
        std = y.std()
        min_v = y.min()
        max_v = y.max()
        
        # Calculate correlation and Mean Absolute Difference with v4
        corr = np.corrcoef(y_v4, y)[0, 1]
        mad = np.mean(np.abs(y_v4 - y))
        
        print(f"=== {label} ({os.path.basename(path)}) ===")
        print(f"  Mean: {mean:.6f}")
        print(f"  Std : {std:.6f}")
        print(f"  Min : {min_v:.6f}")
        print(f"  Max : {max_v:.6f}")
        print(f"  Correlation with v4: {corr:.6f}")
        print(f"  Mean Absolute Difference with v4: {mad:.6f}")
        print("-" * 60)

if __name__ == '__main__':
    main()
