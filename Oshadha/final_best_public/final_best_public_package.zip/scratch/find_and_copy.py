import os
import shutil
import pandas as pd

def validate_file(filepath):
    print(f"\n[VALIDATE] Validating copied file at: {filepath}")
    errors = []
    
    if not os.path.exists(filepath):
        print("   [ERROR] File does not exist!")
        return False
        
    try:
        df = pd.read_csv(filepath)
    except Exception as e:
        print(f"   [ERROR] Failed to read CSV: {e}")
        return False
        
    # 1. 5300 rows
    if len(df) != 5300:
        errors.append(f"Row count is {len(df)}, expected 5300")
        
    # 2. columns exactly record_id, flood_risk_score
    if list(df.columns) != ['record_id', 'flood_risk_score']:
        errors.append(f"Columns are {list(df.columns)}, expected ['record_id', 'flood_risk_score']")
        
    # 3. no missing values
    if df.isna().any().any():
        errors.append("Contains missing values")
        
    # 4. no duplicate record_id
    if df['record_id'].duplicated().any():
        errors.append("Contains duplicate record_ids")
        
    # 5. predictions between 0 and 1
    p_min = df['flood_risk_score'].min()
    p_max = df['flood_risk_score'].max()
    if p_min < 0.0 or p_max > 1.0:
        errors.append(f"Predictions out of range [0, 1]: min={p_min:.6f}, max={p_max:.6f}")
        
    if not errors:
        print("   Success! Copied file passed all validation checks.")
        print(f"   Stats: Row Count={len(df)}, Min={p_min:.6f}, Max={p_max:.6f}, Mean={df['flood_risk_score'].mean():.6f}")
        return True
    else:
        print("   [ERROR] Validation failed:")
        for err in errors:
            print(f"     - {err}")
        return False

def main():
    search_root = r"c:\Users\user\Downloads\KruthimaOps (1)\KruthimaOps"
    targets = [
        "final_best_public_submission.csv",
        "submission_v703_optimized.csv",
        "final_submission_v4.csv",
        "final_submission_v3.csv",
        "mentor_final_package_v4.zip",
        "mentor_final_package_v3.zip"
    ]
    
    found_files = {t: [] for t in targets}
    
    print("=== Searching project folder recursively... ===")
    for root_dir, dirs, files in os.walk(search_root):
        for file in files:
            if file in targets:
                full_path = os.path.join(root_dir, file).replace('\\', '/')
                found_files[file].append(full_path)
                
    for target, paths in found_files.items():
        print(f"\nTarget: {target}")
        if paths:
            for p in paths:
                print(f"  - {p}")
        else:
            print("  - NOT FOUND")
            
    print("\n" + "="*60)
    
    # Identify final public-best
    # The final public-best is submission_v703_optimized.csv (which corresponds to LB 0.38203)
    # Let's find if final_best_public_submission.csv exists
    best_public_paths = found_files["final_best_public_submission.csv"]
    v703_opt_paths = found_files["submission_v703_optimized.csv"]
    
    # Locate Desktop
    home_dir = os.path.expanduser('~')
    desktop_candidates = [
        os.path.join(home_dir, 'Desktop'),
        os.path.join(home_dir, 'OneDrive', 'Desktop')
    ]
    
    desktop_path = None
    for candidate in desktop_candidates:
        if os.path.exists(candidate):
            desktop_path = candidate
            break
            
    if not desktop_path:
        # Fallback to create Desktop folder if not exists, but it should exist on Windows
        desktop_path = os.path.join(home_dir, 'Desktop')
        os.makedirs(desktop_path, exist_ok=True)
        
    dest_path = os.path.join(desktop_path, "final_best_public_submission.csv").replace('\\', '/')
    print(f"Target Desktop Path: {dest_path}")
    
    source_file = None
    if best_public_paths:
        source_file = best_public_paths[0]
        print(f"Found final_best_public_submission.csv. Copying from: {source_file}")
    elif v703_opt_paths:
        source_file = v703_opt_paths[0]
        print(f"final_best_public_submission.csv not found. Copying submission_v703_optimized.csv from: {source_file}")
    else:
        print("ERROR: Neither final_best_public_submission.csv nor submission_v703_optimized.csv found!")
        return
        
    try:
        shutil.copy2(source_file, dest_path)
        print("File copied successfully.")
        validate_file(dest_path)
    except Exception as e:
        print(f"Error during file copy: {e}")

if __name__ == '__main__':
    main()
